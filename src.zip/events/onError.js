
export const onError = (socket) => (data) => {
    console.log(socket);
};