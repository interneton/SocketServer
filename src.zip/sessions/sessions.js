export const gameSessions = [];

export const userSessions = [];