export const TOTAL_LENGTH = 4;
export const PACKET_TYPE_LENGTH = 1;


export const PACKET_TYPE = {
    PING: 0,
    NORMAL: 1,
    LOCATION: 3,
}